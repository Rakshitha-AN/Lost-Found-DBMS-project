<DOCTYPE html>
    <html>
    <head>
        <title>category table></title>
        <!--Internal CSS-->
        <style>
            body{
                background-image:url('background.jpg');
                background-repeat:no-repeat;
                background-attachment:fixed;
                background-size:100% 100%;
            }
            table,th,td{
                border:0px solid #000000;
                border-collapse:collapse;

                
            }
            td{
                text-align:center;
                font-family:bold;
                font-weight:bold;
                font-size:20px;
                padding:20px;
                background:transparent;
                color:#ffffff;
            }
            th{
                padding:20px;
                background:#0c0101;
                color:#ffffff;
                font-weight:bold;
                font-family:bold;
                font-size:20px;
            }
            caption{
                font-size:30px;
                font-family:bold;
                color:#ffffff;
            }
        </style>
    </head>
    <body>


        <table border="1" align="center" width="30%">
            
            
    
            <tr>
                <th>ID</th>
                <th>Category Name</th>
            </tr>
            <tr>
                <td>1</td>
                <td>Mobile</td>
           </tr>
           <tr>
                <td>2</td>
                <td>Stationaries</td>
           </tr>
           <tr>
                <td>3</td>
                <td>Accessories</td>
           </tr>
           <tr>
                <td>4</td>
                <td>Automobiles</td>
           </tr> 
           <tr>
                <td>5</td>
                <td>Laptop</td>
           </tr>
           <tr>
                <td>6</td>
                <td>Keys</td>
           </tr>
           <tr>
                <td>7</td>
                <td>Camera</td>
           </tr>
           <tr>
                <td>8</td>
                <td>Spectacles</td>
           </tr>
           <tr>
                <td>9</td>
                <td>Clothing</td>
           </tr>
           <tr>
                <td>10</td>
                <td>Headphones</td>
       </tr>
        </centre>
        </table>
    </body>
    </html>
    