<?php
    require ('config.php');
    require ('functions.php');
    echo get_catname(15);
?>