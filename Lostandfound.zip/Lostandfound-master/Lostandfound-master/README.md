# lostandfound
Is a web based application where user is provided with an interface for adding a lost or found items, listing and searching of the property's in a database with admin panel.Is built with PHP,HTML and CSS 
