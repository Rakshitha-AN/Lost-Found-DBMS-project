<!DOCTYPE html>
<html>
<head>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="home.css">
	<title>LOST&FOUND</title>
	<style media="screen">
	.full-page{
		height: 100%;
		width: 100%;
		background-image: linear-gradient(rgba(0, 0, 0, 0.5),rgba(0, 0, 0, 0.5)), url(2.jpg);
		background-size: cover;
		background-position: center;
		position: absolute;
	}
  img{
    width: 80px;
    height: 80px;
    border-radius: 100px;
  }
	</style>

<body>


	<div class="full-page">
		<div class="navbar">
			<img src="logo.jpg"  alt="">
			<!--navigation bar-->

			<nav>
				<ul id="MenuItems">
					<li> <a href= "home.php"> Home</a></li>
					<li> <a href="about.html"> About us</a></li>
					<li> <a href= "cat.php"> Category</a></li>
    			<li> <a href="login.php"> Login</a></li>


				</ul>
			</nav>
		 </div>
	</div>

</body>
</html>






























































































































